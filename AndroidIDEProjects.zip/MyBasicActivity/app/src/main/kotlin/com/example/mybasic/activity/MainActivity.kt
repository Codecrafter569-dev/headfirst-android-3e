package com.example.mybasic.activity

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var tvDisplay: TextView

    private var current = ""            // number being typed
    private var firstOperand: Double? = null
    private var operator: String? = null
    private var resultShown = false     // true right after pressing "="

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvDisplay = findViewById(R.id.tvDisplay)
    }

    // ---- Button handlers (wired via android:onClick in the XML) ----

    fun onDigit(view: View) {
        val digit = (view as Button).text.toString()
        if (resultShown) {
            current = ""
            resultShown = false
        }
        current = if (current == "0") digit else current + digit
        updateDisplay()
    }

    fun onDecimal(view: View) {
        if (resultShown) {
            current = ""
            resultShown = false
        }
        if (!current.contains(".")) {
            current = if (current.isEmpty()) "0." else "$current."
        }
        updateDisplay()
    }

    fun onOperator(view: View) {
        val op = (view as Button).text.toString()
        resultShown = false

        if (current.isEmpty()) {
            // Change operator if one was already chosen
            if (firstOperand != null) operator = op
            updateDisplay()
            return
        }

        val value = current.toDouble()
        if (firstOperand != null && operator != null) {
            // Chain: 2 + 3 + ... -> calculate 2 + 3 first
            val result = calculate(firstOperand!!, value, operator!!)
            if (result == null) {
                showError()
                return
            }
            firstOperand = result
        } else {
            firstOperand = value
        }
        operator = op
        current = ""
        updateDisplay()
    }

    fun onEquals(view: View) {
        val a = firstOperand
        val op = operator
        if (a == null || op == null || current.isEmpty()) return

        val result = calculate(a, current.toDouble(), op)
        if (result == null) {
            showError()
            return
        }
        current = format(result)
        firstOperand = null
        operator = null
        resultShown = true
        updateDisplay()
    }

    fun onClear(view: View) {
        current = ""
        firstOperand = null
        operator = null
        resultShown = false
        updateDisplay()
    }

    fun onBackspace(view: View) {
        if (resultShown) return
        current = current.dropLast(1)
        updateDisplay()
    }

    // ---- Helpers ----

    private fun calculate(a: Double, b: Double, op: String): Double? = when (op) {
        "+" -> a + b
        "−" -> a - b
        "×" -> a * b
        "÷" -> if (b == 0.0) null else a / b
        else -> null
    }

    private fun format(value: Double): String =
        if (value % 1.0 == 0.0 && abs(value) < 1e15) value.toLong().toString()
        else value.toString()

    private fun updateDisplay() {
        val first = firstOperand
        tvDisplay.text = when {
            first != null -> "${format(first)} ${operator ?: ""} $current"
            current.isEmpty() -> "0"
            else -> current
        }
    }

    private fun showError() {
        current = ""
        firstOperand = null
        operator = null
        resultShown = false
        tvDisplay.text = "Error"
    }
}
